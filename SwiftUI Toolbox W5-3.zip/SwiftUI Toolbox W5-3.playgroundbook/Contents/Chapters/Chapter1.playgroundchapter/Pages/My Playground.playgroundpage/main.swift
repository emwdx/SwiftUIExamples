import SwiftUI
import PlaygroundSupport

struct MyApp: View{
    
    var body: some View{
        VStack{
            
            Text("This is where you should place your SwiftUI Elements.")
            
            
        }
        
    }
    
    
}

PlaygroundPage.current.setLiveView(MyApp())

